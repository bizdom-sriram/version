import React from 'react'
import AdminPanel from './Components/AdminPanel'

const App = () => <AdminPanel />

export default App;
