import React, { createContext, useContext, useEffect, useState } from 'react';
import { hasBackend, listCandidates, patchCandidate } from '../services/api';

// One shared list of candidates for every screen.
// Pipeline:  registered (form) -> call verified -> virtual interview assigned
//
// With a backend (VITE_API_URL) the list is loaded from it. Without one, the
// list is kept in localStorage so the whole flow can be tried locally.

const STORAGE_KEY = 'admin.candidates';
const CandidatesContext = createContext(null);

export const useCandidates = () => useContext(CandidatesContext);

const readLocal = () => {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; } catch { return []; }
};

// Form data -> stored record. A File can't be stored, so keep its name.
const toRecord = (form) => {
  const { resume, ...rest } = form;
  return { ...rest, resumeName: resume?.name || '' };
};

// Backend record -> the shape the screens expect.
const normalize = (c) => ({
  ...c,
  id: c.id ?? c._id,
  resumeName: c.resumeName ?? (typeof c.resume === 'string' ? c.resume : c.resume?.name) ?? '',
  callVerified: c.callVerified === true || c.callVerified === 'true',
  // true once the candidate's full details were completed through Edit
  edited: c.edited === true || c.edited === 'true',
  interview: c.interview ?? null,
});

export const CandidatesProvider = ({ children }) => {
  const [candidates, setCandidates] = useState(() => (hasBackend ? [] : readLocal()));
  const [loading, setLoading] = useState(hasBackend);
  const [loadError, setLoadError] = useState('');

  useEffect(() => {
    if (hasBackend) return;
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(candidates)); } catch { /* storage full/blocked */ }
  }, [candidates]);

  useEffect(() => {
    if (!hasBackend) return;
    listCandidates()
      .then((list) => setCandidates(list.map(normalize)))
      .catch((e) => setLoadError(e.message))
      .finally(() => setLoading(false));
  }, []);

  // Called by the form after it saves. Creates the candidate, or updates it after an edit
  // (call-verification and interview status are kept).
  // `extra` is merged on top, e.g. { edited: true }.
  const saveCandidate = (id, form, extra = {}) => {
    const data = { ...toRecord(form), ...extra };
    setCandidates((prev) =>
      prev.some((c) => c.id === id)
        ? prev.map((c) => (c.id === id ? { ...c, ...data } : c))
        : [...prev, { id, ...data, callVerified: false, edited: false, interview: null, submittedAt: new Date().toISOString() }]
    );
  };

  // Optimistic update; rolls back and rethrows if the backend rejects it.
  const applyPatch = async (ids, patch) => {
    const before = candidates;
    setCandidates((prev) => prev.map((c) => (ids.includes(c.id) ? { ...c, ...patch } : c)));
    try {
      await Promise.all(ids.map((id) => patchCandidate(id, patch)));
    } catch (e) {
      setCandidates(before);
      throw e;
    }
  };

  // Un-verifying also drops any interview already assigned.
  const setCallVerified = (id, verified) =>
    applyPatch([id], verified ? { callVerified: true } : { callVerified: false, interview: null });

  const assignInterview = (ids, interview) => applyPatch(ids, { interview });

  return (
    <CandidatesContext.Provider
      value={{ candidates, loading, loadError, saveCandidate, setCallVerified, assignInterview }}
    >
      {children}
    </CandidatesContext.Provider>
  );
};
