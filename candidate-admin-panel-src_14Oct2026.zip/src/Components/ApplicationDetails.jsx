import React from 'react';
import './MultiStepForm.css';

const yesNo = (v) => (v === 'yes' ? 'Yes' : v === 'no' ? 'No' : '');
const isTrue = (v) => v === true || v === 'true';
const isFalse = (v) => v === false || v === 'false';

const Row = ({ label, value }) => (
  <p className="review-row">
    <span className="review-label">{label}</span>
    <span className="review-value">{value || '—'}</span>
  </p>
);

// The complete application, grouped by the 4 form pages.
// Used on the form's final page, in the On site Process pop-up, and when printing.
const ApplicationDetails = ({ data }) => {
  const resumeName = data.resume?.name || data.resumeName;
  return (
    <div className="review-display-grid">
      <div className="review-card">
        <h3 className="review-subtitle">Page 1: Basic Information</h3>
        <Row label="Full Name" value={data.name} />
        <Row label="Mobile Number" value={data.mobile} />
        <Row label="Email Address" value={data.email} />
        <Row label="Current Location" value={data.location} />
        <Row label="Highest Qualification" value={data.qualification} />
        <Row label="Passed Out Year" value={data.passedOutYear} />
        <Row label="Experience Level" value={data.experience === 'experience' ? 'Experienced' : 'Fresher'} />
        {data.experience === 'experience' && (
          <>
            <Row label="Organisation" value={data.organisation} />
            <Row label="Relieving Date" value={data.relievingDate} />
          </>
        )}
        <Row label="LinkedIn URL" value={data.linkedinUrl} />
        <Row label="Resume" value={resumeName} />
      </div>

      <div className="review-card">
        <h3 className="review-subtitle">Page 2: Availability Status</h3>
        <Row label="Available for On-site Visit" value={yesNo(data.availableToTalk)} />
      </div>

      <div className="review-card">
        <h3 className="review-subtitle">Page 3: Interview Details</h3>
        <Row label="Available for Virtual Interview" value={yesNo(data.virtualInterview)} />
        {data.virtualInterview === 'no' &&
          (data.date ? (
            <>
              <Row label="Reschedule Date" value={data.date} />
              <Row label="Reschedule Time" value={data.time} />
              <Row label="Reason" value={data.reason} />
            </>
          ) : (
            <Row label="Processing Path" value="Submitted without rescheduling" />
          ))}
      </div>

      <div className="review-card">
        <h3 className="review-subtitle">Page 4: Additional Details</h3>
        <Row label="Native Place" value={data.native} />
        <Row label="Current Exact Location" value={data.currentLocation} />
        <Row label="Expected Annual Salary" value={data.expectedSalary} />
        <Row label="Minimum Planned Stay" value={data.yearsToStay ? `${data.yearsToStay} years` : ''} />
        <Row label="Open to Relocation" value={isTrue(data.relocate) ? 'Yes' : isFalse(data.relocate) ? 'No' : ''} />
      </div>
    </div>
  );
};

export default ApplicationDetails;
