import React, { useState } from 'react';
import { useCandidates } from '../context/CandidatesContext';
import Modal from './Modal';

const todayLocal = () => {
  const d = new Date();
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 10);
};

const virtualLabel = (c) => {
  if (c.virtualInterview === 'yes') return 'Available';
  if (c.virtualInterview === 'no') return c.date ? `Not available (prefers ${c.date} ${c.time})` : 'Not available';
  return '—';
};

const VirtualProcess = () => {
  const { candidates, assignInterview } = useCandidates();
  const [selected, setSelected] = useState([]);
  const [showAssign, setShowAssign] = useState(false);
  const [form, setForm] = useState({ date: '', time: '', interviewer: '' });
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  // Only call-verified candidates reach this stage.
  const verified = candidates.filter((c) => c.callVerified);
  // Ignore selections for anyone who is no longer verified.
  const selectedIds = selected.filter((id) => verified.some((c) => c.id === id));
  const allSelected = verified.length > 0 && selectedIds.length === verified.length;

  const toggleOne = (id) =>
    setSelected((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  const toggleAll = () => setSelected(allSelected ? [] : verified.map((c) => c.id));

  const openAssign = () => {
    setForm({ date: '', time: '', interviewer: '' });
    setErrors({});
    setShowAssign(true);
  };

  const confirmAssign = async (e) => {
    e.preventDefault();
    const next = {};
    if (!form.date) next.date = 'Date is required';
    else if (form.date < todayLocal()) next.date = 'Date cannot be in the past';
    if (!form.time) next.time = 'Time is required';
    setErrors(next);
    if (Object.keys(next).length) return;

    setSaving(true);
    try {
      await assignInterview(selectedIds, { date: form.date, time: form.time, interviewer: form.interviewer.trim() });
      setSelected([]);
      setShowAssign(false);
    } catch (err) {
      setErrors({ form: err.message || 'Could not assign. Please try again.' });
    } finally {
      setSaving(false);
    }
  };

  const setField = (e) => setForm((p) => ({ ...p, [e.target.name]: e.target.value }));

  return (
    <div className="module-card">
      <div className="module-head">
        <label className="check-label">
          <input type="checkbox" checked={allSelected} onChange={toggleAll} disabled={!verified.length} />
          Select all ({selectedIds.length} selected)
        </label>
        <button type="button" className="action-btn submit-step-btn" disabled={!selectedIds.length} onClick={openAssign}>
          Assign
        </button>
      </div>

      {verified.length === 0 ? (
        <p className="muted">No verified candidates yet. Mark candidates as Verified under Call Verification.</p>
      ) : (
        <ul className="vp-list">
          {verified.map((c) => (
            <li key={c.id} className={`vp-card ${selectedIds.includes(c.id) ? 'is-selected' : ''}`}>
              <input
                type="checkbox"
                aria-label={`Select ${c.name}`}
                checked={selectedIds.includes(c.id)}
                onChange={() => toggleOne(c.id)}
              />
              <div className="vp-body">
                <div className="vp-title">
                  <strong>{c.name}</strong>
                  <span className="badge badge-ok">Call Verified</span>
                  {c.interview && <span className="badge badge-info">Assigned</span>}
                </div>
                <div className="vp-fields">
                  <span><b>Mobile:</b> {c.mobile}</span>
                  <span><b>Email:</b> {c.email}</span>
                  <span><b>Experience:</b> {c.experience === 'experience' ? `Experienced (${c.organisation || '—'})` : 'Fresher'}</span>
                  <span><b>Qualification:</b> {c.qualification || '—'}</span>
                  <span><b>Virtual interview:</b> {virtualLabel(c)}</span>
                  {c.interview && (
                    <span>
                      <b>Scheduled:</b> {c.interview.date} at {c.interview.time}
                      {c.interview.interviewer ? ` with ${c.interview.interviewer}` : ''}
                    </span>
                  )}
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}

      {showAssign && (
        <Modal title="Assign interview date" onClose={() => setShowAssign(false)}>
          <form onSubmit={confirmAssign} noValidate>
            <p className="muted">
              Assigning {selectedIds.length} candidate{selectedIds.length > 1 ? 's' : ''}:{' '}
              {verified.filter((c) => selectedIds.includes(c.id)).map((c) => c.name).join(', ')}
            </p>
            <div className="field-row">
              <div className="field-group">
                <label className="field-label" htmlFor="as-date">Date <span className="req">*</span></label>
                <input id="as-date" type="date" name="date" min={todayLocal()} value={form.date} onChange={setField} className={errors.date ? 'input-error' : ''} />
                {errors.date && <p className="error-msg">{errors.date}</p>}
              </div>
              <div className="field-group">
                <label className="field-label" htmlFor="as-time">Time <span className="req">*</span></label>
                <input id="as-time" type="time" name="time" value={form.time} onChange={setField} className={errors.time ? 'input-error' : ''} />
                {errors.time && <p className="error-msg">{errors.time}</p>}
              </div>
            </div>
            <div className="field-group">
              <label className="field-label" htmlFor="as-int">Assign to (interviewer, optional)</label>
              <input id="as-int" type="text" name="interviewer" value={form.interviewer} onChange={setField} placeholder="Interviewer name" />
            </div>
            {errors.form && <p className="submit-error" role="alert">{errors.form}</p>}
            <div className="navigation-tray">
              <button type="button" className="action-btn back-step-btn" onClick={() => setShowAssign(false)}>Cancel</button>
              <button type="submit" className="action-btn submit-step-btn" disabled={saving}>
                {saving ? 'Assigning...' : 'Assign'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};

export default VirtualProcess;
