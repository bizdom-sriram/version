import React, { useState } from 'react';
import MultiStepForm from './MultiStepForm';
import CallVerification from './CallVerification';
import VirtualProcess from './VirtualProcess';
import OnSiteProcess from './OnSiteProcess';
import { CandidatesProvider } from '../context/CandidatesContext';
import './AdminPanel.css';
import './Modules.css';

const FILTERING_ITEMS = [
  { id: 'raw', label: '1. Raw data' },
  { id: 'call', label: '2. Call Verification' },
  { id: 'virtual', label: '3. Virtual Process' },
];

const TITLES = {
  raw: 'Filtering and Processing / Raw data',
  call: 'Filtering and Processing / Call Verification',
  virtual: 'Filtering and Processing / Virtual Process',
  onsite: 'On site Process',
};

const AdminPanel = () => {
  const [active, setActive] = useState('raw');
  const [filteringOpen, setFilteringOpen] = useState(true);
  const [editing, setEditing] = useState(null); // candidate being edited in the form

  const startEdit = (candidate) => {
    setEditing(candidate);
    setActive('raw');
  };
  const finishEdit = () => {
    setEditing(null);
    setActive('call');
  };

  const navButton = (id, label, extra = '') => (
    <button
      type="button"
      className={`admin-nav-item ${extra} ${active === id ? 'is-active' : ''}`}
      aria-current={active === id ? 'page' : undefined}
      onClick={() => setActive(id)}
    >
      {label}
    </button>
  );

  return (
    <CandidatesProvider>
      <div className="admin-shell">
        <aside className="admin-sidebar">
          <h1 className="admin-brand">Admin Panel</h1>
          <nav aria-label="Admin sections">
            <ul className="admin-nav">
              <li>
                <button
                  type="button"
                  className="admin-nav-item admin-nav-parent"
                  aria-expanded={filteringOpen}
                  onClick={() => setFilteringOpen((o) => !o)}
                >
                  Filtering and Processing <span aria-hidden="true">{filteringOpen ? '▾' : '▸'}</span>
                </button>
                {filteringOpen && (
                  <ul className="admin-nav">
                    {FILTERING_ITEMS.map((s) => (
                      <li key={s.id}>{navButton(s.id, s.label, 'is-sub')}</li>
                    ))}
                  </ul>
                )}
              </li>
              <li>{navButton('onsite', 'On site Process')}</li>
            </ul>
          </nav>
        </aside>

        <main className="admin-main">
          <header className="admin-header">
            <h2>{TITLES[active]}</h2>
          </header>
          <div className="admin-content">
            {/* The form stays mounted so a half-filled application survives switching screens */}
            <div hidden={active !== 'raw'}><MultiStepForm editing={editing} onDone={finishEdit} /></div>
            {active === 'call' && <CallVerification onEdit={startEdit} />}
            {active === 'virtual' && <VirtualProcess />}
            {active === 'onsite' && <OnSiteProcess />}
          </div>
        </main>
      </div>
    </CandidatesProvider>
  );
};

export default AdminPanel;
