import React, { useEffect, useState } from 'react';
import { submitApplication } from '../services/api';
import { useCandidates } from '../context/CandidatesContext';
import ApplicationDetails from './ApplicationDetails';
import './MultiStepForm.css';

const INITIAL_FORM = {
  name: '',
  mobile: '',
  email: '',
  location: '',
  qualification: '',
  passedOutYear: '',
  experience: 'fresher',
  organisation: '',
  relievingDate: '',
  linkedinUrl: '',
  resume: null,
  availableToTalk: null,
  virtualInterview: null,
  date: '',
  time: '',
  reason: '',
  native: '',
  currentLocation: '',
  expectedSalary: '',
  yearsToStay: '',
  relocate: null
};

const MOBILE_LENGTH = 10;       // change here if you need another length
const SUMMARY_SECONDS = 3;      // how long the full summary stays on screen after an edit

// Props (from AdminPanel):
//   editing -> the candidate chosen with "Edit" on Call Verification (or null)
//   onDone  -> called to go to the Call Verification screen
const MultiStepForm = ({ editing = null, onDone = () => {} }) => {
  const { saveCandidate } = useCandidates();
  // Workflow
  //  New candidate : page 1 "Submit" -> saved to DB -> form is cleared (hidden) -> Call Verification
  //  Edit          : page 1-3 "Next", page 4 "Submit" -> full summary for 3 sec -> Call Verification
  const [step, setStep] = useState(1);
  const [isEditMode, setIsEditMode] = useState(false);
  const [candidateId, setCandidateId] = useState(null); // id of the candidate being edited
  const [existingResume, setExistingResume] = useState('');
  const [showReschedule, setShowReschedule] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState({});

  const [formData, setFormData] = useState(INITIAL_FORM);

  // Clears the form without showing it (the form is hidden while another screen is open).
  const resetForm = () => {
    setFormData(INITIAL_FORM);
    setErrors({});
    setSubmitError('');
    setCandidateId(null);
    setExistingResume('');
    setShowReschedule(false);
    setIsEditMode(false);
    setStep(1);
  };

  // "Edit" clicked on Call Verification -> load that candidate back into the form, page 1.
  useEffect(() => {
    if (!editing) return;
    const loaded = { ...INITIAL_FORM };
    Object.keys(INITIAL_FORM).forEach((k) => {
      if (editing[k] !== undefined && editing[k] !== null) loaded[k] = editing[k];
    });
    loaded.resume = null;
    if (loaded.relocate === 'true') loaded.relocate = true;
    if (loaded.relocate === 'false') loaded.relocate = false;
    setFormData(loaded);
    setExistingResume(editing.resumeName || '');
    setShowReschedule(loaded.virtualInterview === 'no' && Boolean(loaded.date));
    setCandidateId(editing.id);
    setErrors({});
    setSubmitError('');
    setIsEditMode(true);
    setStep(1);
  }, [editing]);

  // After the final submit of an edit: show the full summary for 3 seconds, then redirect.
  useEffect(() => {
    if (step !== 5) return;
    const timer = setTimeout(() => {
      resetForm();
      onDone();
    }, SUMMARY_SECONDS * 1000);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  // Mobile: only digits can be typed or pasted.
  const handleMobileChange = (e) => {
    const digits = e.target.value.replace(/\D/g, '').slice(0, MOBILE_LENGTH);
    setFormData((prev) => ({ ...prev, mobile: digits }));
    if (errors.mobile) setErrors((prev) => ({ ...prev, mobile: '' }));
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    setFormData((prev) => ({ ...prev, resume: file }));
  };

  const validateStep = (currentStep) => {
    let newErrors = {};
    switch (currentStep) {
      case 1:
        if (!formData.name.trim()) newErrors.name = 'Name is required';
        if (!formData.mobile) newErrors.mobile = 'Mobile number is required';
        else if (formData.mobile.length !== MOBILE_LENGTH) newErrors.mobile = `Enter a ${MOBILE_LENGTH}-digit mobile number`;
        if (!formData.email.trim()) {
          newErrors.email = 'Email is required';
        } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
          newErrors.email = 'Please enter a valid email address';
        }
        if (formData.experience === 'experience') {
          if (!formData.organisation.trim()) newErrors.organisation = 'Organisation name is required';
          if (!formData.relievingDate) newErrors.relievingDate = 'Relieving date is required';
        }
        break;
      case 2:
        if (formData.availableToTalk === null) {
          newErrors.availableToTalk = 'Please make a selection to proceed';
        }
        break;
      case 3:
        if (formData.availableToTalk === 'yes' && formData.virtualInterview === null) {
          newErrors.virtualInterview = 'Please choose whether you are available for a virtual interview';
        }
        // Date / time / reason are only asked for once "Reschedule" has been opened.
        if (formData.availableToTalk === 'yes' && formData.virtualInterview === 'no' && showReschedule) {
          if (!formData.date) newErrors.date = 'Reschedule date is required';
          if (!formData.time) newErrors.time = 'Reschedule time is required';
          if (!formData.reason.trim()) newErrors.reason = 'Please provide a brief reason';
        }
        break;
      case 4:
        // Additional details are optional. Proceed directly without error mapping.
        break;
      default:
        break;
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Sends the data to the backend (POST for a new candidate, PUT for an edit).
  // New candidate -> clear the form (hidden) and go to Call Verification.
  // Edit          -> show the full summary page; it redirects after 3 seconds.
  // Stays on the current page if the request fails.
  const saveToBackend = async () => {
    setIsSubmitting(true);
    setSubmitError('');
    try {
      if (isEditMode) {
        const backendId = String(candidateId).startsWith('local-') ? null : candidateId;
        await submitApplication({ ...formData, edited: true }, backendId);
        saveCandidate(candidateId, formData, { edited: true });
        setStep(5);
      } else {
        const result = await submitApplication(formData, null);
        saveCandidate(result?.id ?? `local-${Date.now()}`, formData);
        resetForm();
        onDone();
      }
    } catch (error) {
      console.error('Submission failed:', error);
      setSubmitError(error.message || 'Could not save your details. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePrimaryAction = (e) => {
    e.preventDefault();
    if (isSubmitting || !validateStep(step)) return;

    if (!isEditMode) {
      // New candidate: only the Basic Information page; Submit saves it.
      saveToBackend();
      return;
    }

    // Editing: Next on pages 1-3, Submit on page 4
    if (step < 4) setStep(step + 1);
    else saveToBackend();
  };

  const handlePrev = () => {
    setSubmitError('');
    setStep((prev) => prev - 1);
  };

  const primaryLabel = isSubmitting
    ? 'Saving...'
    : isEditMode && step < 4
      ? 'Next'
      : 'Submit';

  return (
    <div className="form-container">
      {step <= 4 && isEditMode && (
        <div className="form-progress">
          <div className="progress-bar-wrapper">
            <div className="progress-line" style={{ width: `${((step - 1) / 3) * 100}%` }}></div>
            {[1, 2, 3, 4].map((num) => (
              <div key={num} className={`progress-node ${step >= num ? 'active' : ''}`}>
                {num}
              </div>
            ))}
          </div>
          <span className="step-counter">Step {step} of 4</span>
        </div>
      )}

      <form onSubmit={handlePrimaryAction} noValidate>
        {/* STEP 1: Basic Information */}
        {step === 1 && (
          <div className="form-section">
            <h2 className="section-title">Basic Information</h2>
            <div className="field-group">
              <label className="field-label">Full Name <span className="req">*</span></label>
              <input type="text" name="name" value={formData.name} onChange={handleInputChange} className={errors.name ? 'input-error' : ''} placeholder="John Doe" />
              {errors.name && <p className="error-msg">{errors.name}</p>}
            </div>
            <div className="field-row">
              <div className="field-group">
                <label className="field-label">Mobile Number <span className="req">*</span></label>
                <input type="tel" inputMode="numeric" name="mobile" maxLength={MOBILE_LENGTH} value={formData.mobile} onChange={handleMobileChange} className={errors.mobile ? 'input-error' : ''} placeholder="9876543210" />
                {errors.mobile && <p className="error-msg">{errors.mobile}</p>}
              </div>
              <div className="field-group">
                <label className="field-label">Email Address <span className="req">*</span></label>
                <input type="email" name="email" value={formData.email} onChange={handleInputChange} className={errors.email ? 'input-error' : ''} placeholder="john@example.com" />
                {errors.email && <p className="error-msg">{errors.email}</p>}
              </div>
            </div>
            <div className="field-row">
              <div className="field-group">
                <label className="field-label">Current Location</label>
                <input type="text" name="location" value={formData.location} onChange={handleInputChange} placeholder="City, Country" />
              </div>
              <div className="field-group">
                <label className="field-label">Highest Qualification</label>
                <input type="text" name="qualification" value={formData.qualification} onChange={handleInputChange} placeholder="B.S. Computer Science" />
              </div>
              <div className="field-group">
                <label className="field-label">Passed Out Year</label>
                <input type="number" name="passedOutYear" value={formData.passedOutYear} onChange={handleInputChange} placeholder="2024" />
              </div>
            </div>
            <div className="field-group">
              <label className="field-label">Experience Level</label>
              <select name="experience" value={formData.experience} onChange={handleInputChange}>
                <option value="fresher">Fresher</option>
                <option value="experience">Experienced</option>
              </select>
            </div>
            {formData.experience === 'experience' && (
              <div className="field-row conditional-box">
                <div className="field-group">
                  <label className="field-label">Organisation <span className="req">*</span></label>
                  <input type="text" name="organisation" value={formData.organisation} onChange={handleInputChange} className={errors.organisation ? 'input-error' : ''} placeholder="Previous Company Name" />
                  {errors.organisation && <p className="error-msg">{errors.organisation}</p>}
                </div>
                <div className="field-group">
                  <label className="field-label">Relieving Date <span className="req">*</span></label>
                  <input type="date" name="relievingDate" value={formData.relievingDate} onChange={handleInputChange} className={errors.relievingDate ? 'input-error' : ''} />
                  {errors.relievingDate && <p className="error-msg">{errors.relievingDate}</p>}
                </div>
              </div>
            )}
            <div className="field-group">
              <label className="field-label">LinkedIn URL</label>
              <input type="url" name="linkedinUrl" value={formData.linkedinUrl} onChange={handleInputChange} placeholder="https://linkedin.com" />
            </div>
            <div className="field-group">
              <label className="field-label">Resume (PDF/DOC/DOCX)</label>
              <div className="file-input-container">
                <input type="file" id="resume-upload" accept=".pdf,.doc,.docx" onChange={handleFileUpload} />
                <label htmlFor="resume-upload" className="file-custom-btn">Choose Document</label>
                <span className="file-name-display">{formData.resume ? formData.resume.name : existingResume || 'No file chosen'}</span>
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: Call Availability Check */}
        {step === 2 && (
          <div className="form-section">
            <h2 className="section-title text-center">Availability Status</h2>
            <div className="field-group text-center">
              <label className="field-label large-label">Are you available for On-site Visit? <span className="req">*</span></label>
              <div className="binary-btn-wrapper">
                <button type="button" className={`action-btn select-opt ${formData.availableToTalk === 'yes' ? 'active-yes' : ''}`} onClick={() => setFormData(prev => ({ ...prev, availableToTalk: 'yes' }))}>Yes</button>
                <button type="button" className={`action-btn select-opt ${formData.availableToTalk === 'no' ? 'active-no' : ''}`} onClick={() => setFormData(prev => ({ ...prev, availableToTalk: 'no' }))}>No</button>
              </div>
              {errors.availableToTalk && <p className="error-msg">{errors.availableToTalk}</p>}
            </div>
          </div>
        )}

        {/* STEP 3: Virtual Interview Routing */}
        {step === 3 && (
          <div className="form-section">
            <h2 className="section-title">Interview Details</h2>
            <div className="field-group text-center">
              <label className="field-label large-label">Are you available for a Virtual Interview? <span className="req">*</span></label>
              <div className="binary-btn-wrapper">
                <button type="button" className={`action-btn select-opt ${formData.virtualInterview === 'yes' ? 'active-yes' : ''}`} onClick={() => { setShowReschedule(false); setFormData(prev => ({ ...prev, virtualInterview: 'yes', date: '', time: '', reason: '' })); }}>Yes</button>
                <button type="button" className={`action-btn select-opt ${formData.virtualInterview === 'no' ? 'active-no' : ''}`} onClick={() => setFormData(prev => ({ ...prev, virtualInterview: 'no' }))}>No</button>
              </div>
              {errors.virtualInterview && <p className="error-msg">{errors.virtualInterview}</p>}
            </div>

            {formData.virtualInterview === 'no' && !showReschedule && (
              <div className="space-top text-center">
                <button type="button" className="action-btn edit-btn" onClick={() => setShowReschedule(true)}>
                  Reschedule
                </button>
              </div>
            )}

            {formData.virtualInterview === 'no' && showReschedule && (
              <div className="space-top text-center">
                <div className="conditional-box text-left">
                  <p className="notice-banner">Suggest an alternate schedule parameter:</p>
                  <div className="field-row">
                    <div className="field-group">
                      <label className="field-label">Preferred Date <span className="req">*</span></label>
                      <input type="date" name="date" value={formData.date} onChange={handleInputChange} className={errors.date ? 'input-error' : ''} />
                      {errors.date && <p className="error-msg">{errors.date}</p>}
                    </div>
                    <div className="field-group">
                      <label className="field-label">Preferred Time <span className="req">*</span></label>
                      <input type="time" name="time" value={formData.time} onChange={handleInputChange} className={errors.time ? 'input-error' : ''} />
                      {errors.time && <p className="error-msg">{errors.time}</p>}
                    </div>
                  </div>
                  <div className="field-group">
                    <label className="field-label">Reason for Rescheduling <span className="req">*</span></label>
                    <textarea name="reason" rows="3" value={formData.reason} onChange={handleInputChange} className={errors.reason ? 'input-error' : ''} placeholder="State reason context..."></textarea>
                    {errors.reason && <p className="error-msg">{errors.reason}</p>}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* STEP 4: Comprehensive Details (All Optional) */}
        {step === 4 && (
          <div className="form-section">
            <h2 className="section-title">Additional Details</h2>
            <div className="field-row">
              <div className="field-group">
                <label className="field-label">Native Place</label>
                <input type="text" name="native" value={formData.native} onChange={handleInputChange} placeholder="City or State" />
              </div>
              <div className="field-group">
                <label className="field-label">Current Exact Location</label>
                <input type="text" name="currentLocation" value={formData.currentLocation} onChange={handleInputChange} placeholder="Street, City" />
              </div>
            </div>
            <div className="field-row">
              <div className="field-group">
                <label className="field-label">Expected Annual Salary</label>
                <input type="number" name="expectedSalary" value={formData.expectedSalary} onChange={handleInputChange} placeholder="Amount" />
              </div>
              <div className="field-group">
                <label className="field-label">Minimum Planned Stay (Years)</label>
                <input type="number" name="yearsToStay" value={formData.yearsToStay} onChange={handleInputChange} placeholder="e.g. 3" />
              </div>
            </div>
            <div className="field-group">
              <label className="field-label">Are you open to relocation?</label>
              <div className="binary-btn-wrapper">
                <button type="button" className={`action-btn select-opt ${formData.relocate === true ? 'active-yes' : ''}`} onClick={() => setFormData(prev => ({ ...prev, relocate: true }))}>Yes</button>
                <button type="button" className={`action-btn select-opt ${formData.relocate === false ? 'active-no' : ''}`} onClick={() => setFormData(prev => ({ ...prev, relocate: false }))}>No</button>
              </div>
            </div>
          </div>
        )}

        {/* STEP 5: Final summary of all 4 pages */}
        {step === 5 && (
          <div className="form-section review-section">
            <div className="summary-head">
              <h2 className="section-title">Application Summary</h2>
            </div>
            <p className="saved-banner" role="status">
              Your details are submitted and saved. Redirecting to Call Verification...
            </p>

            <ApplicationDetails data={{ ...formData, resumeName: existingResume }} />
          </div>
        )}

        {step <= 4 && isEditMode && (
          <p className="edit-banner">Editing this application. Changes are saved when you submit on page 4.</p>
        )}

        {submitError && step <= 4 && (
          <p className="submit-error" role="alert">{submitError}</p>
        )}

        {/* Navigation */}
        <div className="navigation-tray">
          {step > 1 && step <= 4 && (
            <button type="button" onClick={handlePrev} className="action-btn back-step-btn" disabled={isSubmitting}>
              Back
            </button>
          )}
          {step <= 4 && (
            <button type="submit" disabled={isSubmitting} className="action-btn submit-step-btn">
              {primaryLabel}
            </button>
          )}
        </div>
      </form>
    </div>
  );
};

export default MultiStepForm;
