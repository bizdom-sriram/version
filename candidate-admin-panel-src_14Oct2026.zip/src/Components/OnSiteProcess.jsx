import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { useCandidates } from '../context/CandidatesContext';
import ApplicationDetails from './ApplicationDetails';
import Modal from './Modal';

// Sensitive values are masked on the cards; the full form is one click away (i icon).
const stars = (n) => '*'.repeat(Math.max(n, 3));
const maskMobile = (v) => (v ? stars(v.length - 3) + v.slice(-3) : '—');
const maskText = (v) => (v ? v[0] + stars(v.length - 1) : '—');
const maskEmail = (v) => {
  if (!v) return '—';
  const [user, domain = ''] = v.split('@');
  return `${user[0]}${stars(user.length - 1)}@${domain}`;
};

const PrinterIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M6 9V2h12v7" /><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2" /><rect x="6" y="14" width="12" height="8" />
  </svg>
);

const InfoIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <circle cx="12" cy="12" r="10" /><line x1="12" y1="16" x2="12" y2="12" /><line x1="12" y1="8" x2="12.01" y2="8" />
  </svg>
);

const OnSiteProcess = () => {
  const { candidates, loading, loadError } = useCandidates();
  const [viewId, setViewId] = useState(null);
  const [printJob, setPrintJob] = useState(null); // { id, key }

  const viewing = candidates.find((c) => c.id === viewId);
  // printJob.id is a candidate id, or 'all' to print every form (one per page).
  const printList = !printJob
    ? []
    : printJob.id === 'all'
      ? candidates
      : candidates.filter((c) => c.id === printJob.id);

  // Print only this candidate's full form: it is rendered in a print-only
  // block outside the app (see print rules in Modules.css), then the dialog opens.
  useEffect(() => {
    if (!printJob) return undefined;
    const clear = () => setPrintJob(null);
    window.addEventListener('afterprint', clear, { once: true });
    const t = setTimeout(() => window.print(), 50);
    return () => {
      clearTimeout(t);
      window.removeEventListener('afterprint', clear);
    };
  }, [printJob]);

  return (
    <div className="module-card">
      <div className="module-head">
        <h3>Application forms</h3>
        <span className="head-right">
          <span className="muted">{candidates.length} candidate{candidates.length === 1 ? '' : 's'}</span>
          <button
            type="button"
            className="action-btn submit-step-btn"
            disabled={candidates.length === 0}
            onClick={() => setPrintJob({ id: 'all', key: Date.now() })}
          >
            Print All
          </button>
        </span>
      </div>

      {loading && <p className="muted">Loading candidates...</p>}
      {loadError && <p className="submit-error" role="alert">{loadError}</p>}

      {!loading && candidates.length === 0 ? (
        <p className="muted">No applications yet. Submitted forms appear here.</p>
      ) : (
        <div className="cand-grid">
          {candidates.map((c) => (
            <article key={c.id} className="cand-card">
              <div className="cand-head">
                <strong>{c.name}</strong>
                <span className="cand-actions">
                  <button type="button" className="icon-btn" title="Print form" aria-label={`Print ${c.name}'s form`} onClick={() => setPrintJob({ id: c.id, key: Date.now() })}>
                    <PrinterIcon />
                  </button>
                  <button type="button" className="icon-btn" title="View full form" aria-label={`View ${c.name}'s full form`} onClick={() => setViewId(c.id)}>
                    <InfoIcon />
                  </button>
                </span>
              </div>
              <p className="review-row"><span className="review-label">Mobile</span><span className="review-value">{maskMobile(c.mobile)}</span></p>
              <p className="review-row"><span className="review-label">Email</span><span className="review-value">{maskEmail(c.email)}</span></p>
              <p className="review-row"><span className="review-label">Location</span><span className="review-value">{maskText(c.location)}</span></p>
              <p className="review-row"><span className="review-label">Salary</span><span className="review-value">{c.expectedSalary ? stars(String(c.expectedSalary).length) : '—'}</span></p>
              <p className="review-row"><span className="review-label">Experience</span><span className="review-value">{c.experience === 'experience' ? 'Experienced' : 'Fresher'}</span></p>
              <p className="review-row"><span className="review-label">On-site visit</span><span className="review-value">{c.availableToTalk === 'yes' ? 'Available' : c.availableToTalk === 'no' ? 'Not available' : '—'}</span></p>
            </article>
          ))}
        </div>
      )}

      {viewing && (
        <Modal title={`${viewing.name}: full application form`} onClose={() => setViewId(null)}>
          <ApplicationDetails data={viewing} />
        </Modal>
      )}

      {printList.length > 0 &&
        createPortal(
          <div className="print-area">
            {printList.map((c) => (
              <section key={c.id} className="print-page">
                <h2>Candidate Application Form: {c.name}</h2>
                <ApplicationDetails data={c} />
              </section>
            ))}
          </div>,
          document.body
        )}
    </div>
  );
};

export default OnSiteProcess;
