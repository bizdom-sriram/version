import React, { useState } from 'react';
import { useCandidates } from '../context/CandidatesContext';

const CallVerification = ({ onEdit = () => {} }) => {
  const { candidates, loading, loadError, setCallVerified } = useCandidates();
  const [error, setError] = useState('');

  const toggle = async (c) => {
    if (c.callVerified && c.interview) {
      const ok = window.confirm(
        `${c.name} already has a virtual interview assigned. Marking as Not Verified will remove it. Continue?`
      );
      if (!ok) return;
    }
    setError('');
    try {
      await setCallVerified(c.id, !c.callVerified);
    } catch (e) {
      setError(e.message || 'Could not update. Please try again.');
    }
  };

  const verifiedCount = candidates.filter((c) => c.callVerified).length;

  return (
    <div className="module-card">
      <div className="module-head">
        <h3>Registered candidates</h3>
        <span className="muted">{verifiedCount} of {candidates.length} verified</span>
      </div>

      {loading && <p className="muted">Loading candidates...</p>}
      {loadError && <p className="submit-error" role="alert">{loadError}</p>}
      {error && <p className="submit-error" role="alert">{error}</p>}

      {!loading && candidates.length === 0 ? (
        <p className="muted">No one has registered yet. Applications submitted under Raw data appear here.</p>
      ) : (
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>No.</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Mail</th>
                <th>Call Verified</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {candidates.map((c, i) => (
                <tr key={c.id}>
                  <td>{i + 1}</td>
                  <td>{c.name}</td>
                  <td>{c.mobile}</td>
                  <td>{c.email}</td>
                  <td>
                    <label className="check-label">
                      <input type="checkbox" checked={c.callVerified} onChange={() => toggle(c)} />
                      {c.callVerified ? 'Verified' : 'Not Verified'}
                    </label>
                  </td>
                  <td>
                    {/* Once the full details have been edited and submitted, Edit is locked */}
                    <button
                      type="button"
                      className="action-btn edit-btn"
                      disabled={c.edited}
                      title={c.edited ? 'Details already completed' : 'Edit details'}
                      onClick={() => onEdit(c)}
                    >
                      {c.edited ? 'Edited' : 'Edit'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default CallVerification;
