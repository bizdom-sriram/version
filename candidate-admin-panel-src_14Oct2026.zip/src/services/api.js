// Backend connectivity for the application form.
//
// Set your endpoint in a `.env` file at the project root:
//   VITE_API_URL=https://yourdomain.com/api/applications
//   VITE_API_TOKEN=optional-bearer-token
//
// First save  -> POST   {VITE_API_URL}
// Later edits -> PUT    {VITE_API_URL}/{id}   (id is read from the first response)
//
// If VITE_API_URL is not set, nothing is sent and the call is logged to the
// console, so the UI can still be tried locally.

const API_URL = import.meta.env.VITE_API_URL;
const API_TOKEN = import.meta.env.VITE_API_TOKEN;

const buildPayload = (data) => {
  const payload = new FormData();
  Object.entries(data).forEach(([key, value]) => {
    if (value === null || value === undefined || value === '') return;
    // `resume` is a File object; everything else is sent as text.
    // (`edited` is sent as "true" once the full details were completed.)
    payload.append(key, value);
  });
  return payload;
};

export async function submitApplication(data, existingId = null) {
  if (!API_URL) {
    console.warn('[api] VITE_API_URL is not set. Skipping network call. Payload:', data);
    return { id: existingId, skipped: true };
  }

  const isUpdate = Boolean(existingId);
  const headers = {};
  if (API_TOKEN) headers.Authorization = `Bearer ${API_TOKEN}`;
  // Do not set Content-Type: the browser adds the multipart boundary for FormData.

  const response = await fetch(isUpdate ? `${API_URL}/${existingId}` : API_URL, {
    method: isUpdate ? 'PUT' : 'POST',
    headers,
    body: buildPayload(data),
  });

  let body = null;
  try {
    body = await response.json();
  } catch {
    // Response had no JSON body; that's fine as long as the status is OK.
  }

  if (!response.ok) {
    throw new Error(body?.message || `Server responded with status ${response.status}`);
  }

  return { id: body?.id ?? body?._id ?? body?.data?.id ?? existingId, body };
}

// ---------------------------------------------------------------------------
// Candidate list + status updates (used by Call Verification / Virtual Process)
//
// GET   {VITE_API_URL}        -> array of candidates (or { data: [...] })
// PATCH {VITE_API_URL}/{id}   -> JSON body, e.g. { callVerified: true }
//                                or { interview: { date, time, interviewer } }
// Adjust these two calls if your backend uses different routes.
// ---------------------------------------------------------------------------

export const hasBackend = Boolean(API_URL);

const authHeaders = () => (API_TOKEN ? { Authorization: `Bearer ${API_TOKEN}` } : {});

export async function listCandidates() {
  const response = await fetch(API_URL, { headers: authHeaders() });
  if (!response.ok) throw new Error(`Could not load candidates (status ${response.status})`);
  const body = await response.json();
  return Array.isArray(body) ? body : body?.data ?? [];
}

export async function patchCandidate(id, patch) {
  if (!hasBackend || String(id).startsWith('local-')) return null;
  const response = await fetch(`${API_URL}/${id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(patch),
  });
  if (!response.ok) {
    let message = '';
    try { message = (await response.json())?.message; } catch { /* no body */ }
    throw new Error(message || `Update failed (status ${response.status})`);
  }
  return null;
}
